from django.apps import AppConfig


class CardapioConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cardapio'
